


var RocknCoder = RocknCoder || {};
RocknCoder.Pages = RocknCoder.Pages || {};

RocknCoder.Pages.Kernel = function (event) {
	var that = this,
		eventType = event.type,
		pageName = $(this).attr("data-rockncoder-jspage");
	if (RocknCoder && RocknCoder.Pages && pageName && RocknCoder.Pages[pageName] && RocknCoder.Pages[pageName][eventType]) {
		RocknCoder.Pages[pageName][eventType].call(that);
	}
};

RocknCoder.Pages.Events = (function () {
	$("div[data-rockncoder-jspage]").on(
		'pagebeforecreate pagecreate pagebeforeload pagebeforeshow pageshow pagebeforechange pagechange pagebeforehide pagehide pageinit',
		RocknCoder.Pages.Kernel
	);
}());

RocknCoder.Pages.loginPage = (function () {
	var pageinit = function () {
		},
		pageshow = function () {
		},
		pagehide = function () {
		};
	return {
		pageinit: pageinit,
		pageshow: pageshow,
		pagehide: pagehide
	};
}());

RocknCoder.Pages.messageList = (function () {
	var pageinit = function () {
		},
		pageshow = function () {
		},
		pagehide = function () {
		};
	return {
		pageinit: pageinit,
		pageshow: pageshow,
		pagehide: pagehide
	};
}());

RocknCoder.Pages.page3 = (function () {
                          var pageinit = function () {
                          },
                          pageshow = function () {
                          },
                          pagehide = function () {
                          };
                          return {
                          pageinit: pageinit,
                          pageshow: pageshow,
                          pagehide: pagehide
                          };
                          }());

RocknCoder.Pages.page4 = (function () {
                          var pageinit = function () {
                          },
                          pageshow = function () {
                          },
                          pagehide = function () {
                          };
                          return {
                          pageinit: pageinit,
                          pageshow: pageshow,
                          pagehide: pagehide
                          };
                          }());

