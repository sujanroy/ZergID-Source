<div> <?php echo HTML::image("public/images/wood.png", array('style'=>'margin-top:-17px;'));?></div>

