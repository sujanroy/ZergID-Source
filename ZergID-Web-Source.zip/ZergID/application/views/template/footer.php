<div class="footer" style="margin-left: -1px;">
    <div class="footer_left"><p class="copyright"><span>&#169;</span> 2013 Zerg, Inc</p></div>
    <div class="footer_center">
        <p class="stuff">Other Stuff</p>
        <a href="<?= URL :: site();?>page/index" class="link_11">About</a><br>
        <a href="<?= URL :: site();?>page/support" class="link_11">Support</a>
    </div>
    <div class="footer_right">
        <p class="stuff">Legal Stuff</p>
        <a href="<?= URL :: site();?>page/privacy" class="link_11">Privacy Policy</a><br>
        <a href="<?= URL :: site();?>page/terms" class="link_11">Terms of Service</a>
    </div>
</div>
