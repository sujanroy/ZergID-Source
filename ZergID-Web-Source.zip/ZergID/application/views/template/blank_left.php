<div align="left"><?php echo $left_content; ?></div>
