
<div class="home_title" align="center">
<span align="center"><p class="home-logo"><?=HTML::image("public/images/logo.png");?></h1></p></span>
    <span class="alpha_header_title">We're Currently Testing</span> <br />   
<span class="header-content">
    Interested in helping us test Zerg ID? Sign up below to join our closed Alpha as room opens up. See you on the inside
</span>
</div>
