<div class="home_title" align="center">
<!--<span align="center"><p class="home-logo"></h1></p>-->
<!--<span align="center" class="header-content">
    Zerg ID is a social network for MMORPG gamers. Setup a Zerg ID and stay
    connected with game friends via your game's characters. Form guilds to chat,
    post, and manage schedules. Share screenshots and videos, post messages to 
    friends and guilds profile feeds, and more.
</span>-->
</div>
