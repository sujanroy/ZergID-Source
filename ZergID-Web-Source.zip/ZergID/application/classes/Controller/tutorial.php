<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Tutorial extends Controller_Template {
    public $template ="tutorial/index"; 
    public function action_index(){
        
    }
}