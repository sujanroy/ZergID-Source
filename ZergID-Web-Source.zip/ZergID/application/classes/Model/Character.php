<?php defined('SYSPATH') or die('No direct script access.');

class Model_Character extends ORM  {
    protected $_table_name = 'zid_characters';
    protected $_primary_key = 'character_id';
  
  
}