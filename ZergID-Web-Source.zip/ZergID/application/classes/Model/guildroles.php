<?php defined('SYSPATH') or die('No direct script access.');

class Model_GuildRoles extends ORM  {
    protected $_table_name = 'zid_guild_roles';
    
    
   
}