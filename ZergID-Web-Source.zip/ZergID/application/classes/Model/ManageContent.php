<?php defined('SYSPATH') or die('No direct script access.');

class Model_ManageContent extends ORM  {
    protected $_table_name = 'zid_manage_content';
    protected $_primary_key = 'id';    
}
