<?php defined('SYSPATH') or die('No direct script access.');

class Kodoc_Method extends Kohana_Kodoc_Method {} 