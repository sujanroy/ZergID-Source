<?php defined('SYSPATH') OR die('No direct script access.');

return array
(
	'modules' => array(
		'unittest' => array(
			'enabled' => TRUE,
			'name' => 'Unittest',
			'description' => 'Unit testing module',
			'copyright' => '&copy; 2009-2011 Kohana Team',
		)
	)
);